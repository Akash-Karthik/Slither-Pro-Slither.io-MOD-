chrome["browserAction"]["onClicked"].addListener(function() {
    window.open("http://slither.io/", "_new")
})